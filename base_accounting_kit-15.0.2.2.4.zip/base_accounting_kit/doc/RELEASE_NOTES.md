## Module <base_accounting_kit>

#### 06.10.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Odoo 15 accounting

#### 20.11.2021
#### Version 15.0.2.0.1
#### ADD
- Added specific user group for Accounting Dashboard view.


#### 14.01.2022
#### Version 15.0.2.0.2
#### FIX
- Dashboard cash and bank balance issue fix

#### 11.04.2023
#### Version 15.0.2.2.3
#### FIX
- Profit and Loss report issue fix

#### 28.04.2023
#### Version 15.0.2.2.4
#### FIX
- asset closing issue is fixed